# ffmpeg -i xxx.mp4 xxx.gif
