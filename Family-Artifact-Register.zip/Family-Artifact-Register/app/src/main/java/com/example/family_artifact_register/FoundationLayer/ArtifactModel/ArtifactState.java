package com.example.family_artifact_register.FoundationLayer.ArtifactModel;

public enum ArtifactState {
    
}
