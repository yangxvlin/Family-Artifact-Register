package com.example.family_artifact_register;

import android.view.View;

public interface ItemClickListener {

    void OnItemClickListener(View v, int Position);
}
