package com.example.family_artifact_register.FoundationLayer;

/**
 * @author XuLin Yang 904904,
 * @time 2019-9-15 23:54:43
 * @description data type to represent the location in the map
 */
public class MapLocation {
}
