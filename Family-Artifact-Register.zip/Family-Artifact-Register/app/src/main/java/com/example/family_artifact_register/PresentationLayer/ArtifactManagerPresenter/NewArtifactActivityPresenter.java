package com.example.family_artifact_register.PresentationLayer.ArtifactManagerPresenter;

import android.view.View;

/**
 * @author XuLin Yang 904904,
 * @time 2019-9-15 23:40:22
 * @description presenter for activity of the user to manage artifacts
 */
public class NewArtifactActivityPresenter {

    private View view;

    public interface View{

    }
}
