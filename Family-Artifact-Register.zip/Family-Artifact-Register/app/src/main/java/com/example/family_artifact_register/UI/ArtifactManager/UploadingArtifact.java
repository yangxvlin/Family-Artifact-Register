package com.example.family_artifact_register.UI.ArtifactManager;

public class UploadingArtifact {
    public static final String ARTIFACT_DESCRIPTION = "Description";
    public static final String ARTIFACT_IMAGES = "Images";
}
